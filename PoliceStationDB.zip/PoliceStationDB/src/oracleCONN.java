
/*import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException; */

import java.sql.*;  

class OracleCONN
{  
	Connection con;
	Statement stmt;
	ResultSet rs;
	OracleCon(){
		connect();
	}
	void connect() {
		
		try{  
			//step1 load the driver class  
			Class.forName("oracle.jdbc.driver.OracleDriver");   // or Class.forName("oracle.jdbc.OracleDriver");
			  
			//step2 create  the connection object  
			 con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","saikumar","sql");  
			  
			//step3 create the statement object  
			 stmt=con.createStatement();  
			  
			//step4 execute query  
		//	ResultSet rs=stmt.executeQuery("select * from officers");  
			  
			//step5 close the connection object  
			//con.close();  
			  
			}catch(Exception e){ System.out.println(e);}  
			  
	}  
}  
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableModel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.PreparedStatement;
import java.awt.event.ActionEvent;

 class ADDJAIL{

	private JFrame frame;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	Connection con;
	Statement stmt;
	ResultSet rs;

	/**
	 * Create the application.
	 */
	public ADDJAIL() {
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
		initialize();
		this.frame.setVisible(true);
	}
    void connectToDB() 
    {
		try 
		{
		 con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","saikumar","sql");
		  stmt = con.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 733, 393);
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("jail id");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblNewLabel.setBounds(178, 72, 165, 32);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("name of the jail");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblNewLabel_1.setBounds(116, 142, 217, 32);
		frame.getContentPane().add(lblNewLabel_1);
		
		textField = new JTextField();
		textField.setBounds(299, 77, 189, 28);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setBounds(299, 147, 189, 28);
		frame.getContentPane().add(textField_1);
		textField_1.setColumns(10);
		
		
		
		JButton btnNewButton = new JButton("ADD DETAILS");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (e.getSource() == btnNewButton) {
					  String name;
			           String reason;
			           
			            int id;
			            id = Integer.parseInt(textField.getText());
			            name=textField_1.getText();
			           
			            try {
			            //System.out.println(userText);
			            	 PreparedStatement pstmt = con.prepareStatement("insert into jail(jailid,jailname) values (?,?)");
			            	        pstmt.setInt(1, id);
			            	        pstmt.setString(2,  name);
			            	       
			            	       
			            	        int i=pstmt.executeUpdate();  
						    //txtmsg.append("\nInserted " + i + " rows successfully");
							JOptionPane.showMessageDialog(null, "\nInserted " + i + " rows successfully");
				   }
			            catch(Exception E)
			            { System.out.println(E);}  
			}
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 16));
		btnNewButton.setBounds(116, 251, 189, 39);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("clear");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				  if (e.getSource() == btnNewButton_1) {
					  textField.setText("");
					  textField_1.setText("");
					  textField_2.setText("");
					  
			        }
			}
		});
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 16));
		btnNewButton_1.setBounds(435, 251, 120, 39);
		frame.getContentPane().add(btnNewButton_1);
		
		
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}
 
 class EDITJAIL{

		private JFrame frame;
		private JTextField textField;
		private JTextField textField_1;
		private JTextField textField_2;
		Connection con;
		Statement stmt;
		ResultSet rs;
		private JTextField txtEditJail;

		/**
		 * Create the application.
		 */
		public EDITJAIL() {
			try 
			{
				Class.forName("oracle.jdbc.driver.OracleDriver");
			} 
			catch (Exception e) 
			{
				System.err.println("Unable to find and load driver");
				System.exit(1);
			}
			connectToDB();
			initialize();
			this.frame.setVisible(true);
		}
	    void connectToDB() 
	    {
			try 
			{
			 con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","saikumar","sql");
			  stmt = con.createStatement();

			} 
			catch (SQLException connectException) 
			{
			  System.out.println(connectException.getMessage());
			  System.out.println(connectException.getSQLState());
			  System.out.println(connectException.getErrorCode());
			  System.exit(1);
			}
	    }
		/**
		 * Initialize the contents of the frame.
		 */
		private void initialize() {
			frame = new JFrame();
			frame.setBounds(100, 100, 733, 393);
			frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
			frame.getContentPane().setLayout(null);
			
			JLabel lblNewLabel = new JLabel("jail id");
			lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 16));
			lblNewLabel.setBounds(178, 72, 165, 32);
			frame.getContentPane().add(lblNewLabel);
			
			JLabel lblNewLabel_1 = new JLabel("name of the jail");
			lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 16));
			lblNewLabel_1.setBounds(116, 142, 217, 32);
			frame.getContentPane().add(lblNewLabel_1);
			
			textField = new JTextField();
			textField.setBounds(299, 77, 189, 28);
			frame.getContentPane().add(textField);
			textField.setColumns(10);
			
			textField_1 = new JTextField();
			textField_1.setBounds(299, 147, 189, 28);
			frame.getContentPane().add(textField_1);
			textField_1.setColumns(10);
			
			
			
			JButton btnNewButton = new JButton("ADD DETAILS");
			btnNewButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if (e.getSource() == btnNewButton) {
						  String name;
				        
				           
				            int id;
				            id = Integer.parseInt(textField.getText());
				            name=textField_1.getText();
				           
				            try {
				            //System.out.println(userText);
				            	 PreparedStatement pstmt = con.prepareStatement("update jail set jailname=(?) where jailid=(?)");
				            	        pstmt.setInt(2, id);
				            	        pstmt.setString(1,  name);
				            	       
				            	       
				            	        int i=pstmt.executeUpdate();  
							    //txtmsg.append("\nInserted " + i + " rows successfully");
								JOptionPane.showMessageDialog(null, "\nUpdated " + i + " rows successfully");
					   }
				            catch(Exception E)
				            { System.out.println(E);}  
				}
				}
			});
			btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 16));
			btnNewButton.setBounds(116, 251, 189, 39);
			frame.getContentPane().add(btnNewButton);
			
			JButton btnNewButton_1 = new JButton("VIEW JAIL DETAILS");
			btnNewButton_1.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					 
					
							if (e.getSource() == btnNewButton_1) {	
							VIEWJAIL vj=new VIEWJAIL();
						
							}
						
					
				}
			});
			btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 16));
			btnNewButton_1.setBounds(402, 251, 224, 39);
			frame.getContentPane().add(btnNewButton_1);
			
			txtEditJail = new JTextField();
			txtEditJail.setFont(new Font("Tahoma", Font.BOLD, 16));
			txtEditJail.setText("EDIT JAIL");
			txtEditJail.setBounds(247, 10, 109, 30);
			frame.getContentPane().add(txtEditJail);
			txtEditJail.setColumns(10);
			
			
			frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		}
		
	}
 
 class DELETEJAIL{

		private JFrame frame;
		private JTextField textField;
		private JTextField textField_1;
		private JTextField textField_2;
		Connection con;
		Statement stmt;
		ResultSet rs;
		private JTextField txtEditJail;

		/**
		 * Create the application.
		 */
		public DELETEJAIL() {
			try 
			{
				Class.forName("oracle.jdbc.driver.OracleDriver");
			} 
			catch (Exception e) 
			{
				System.err.println("Unable to find and load driver");
				System.exit(1);
			}
			connectToDB();
			initialize();
			this.frame.setVisible(true);
		}
	    void connectToDB() 
	    {
			try 
			{
			 con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","saikumar","sql");
			  stmt = con.createStatement();

			} 
			catch (SQLException connectException) 
			{
			  System.out.println(connectException.getMessage());
			  System.out.println(connectException.getSQLState());
			  System.out.println(connectException.getErrorCode());
			  System.exit(1);
			}
	    }
		/**
		 * Initialize the contents of the frame.
		 */
		private void initialize() {
			frame = new JFrame();
			frame.setBounds(100, 100, 733, 393);
			frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
			frame.getContentPane().setLayout(null);
			
			JLabel lblNewLabel = new JLabel("jail id");
			lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 16));
			lblNewLabel.setBounds(178, 72, 165, 32);
			frame.getContentPane().add(lblNewLabel);
			
			JLabel lblNewLabel_1 = new JLabel("name of the jail");
			lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 16));
			lblNewLabel_1.setBounds(116, 142, 217, 32);
			frame.getContentPane().add(lblNewLabel_1);
			
			textField = new JTextField();
			textField.setBounds(299, 77, 189, 28);
			frame.getContentPane().add(textField);
			textField.setColumns(10);
			
			textField_1 = new JTextField();
			textField_1.setBounds(299, 147, 189, 28);
			frame.getContentPane().add(textField_1);
			textField_1.setColumns(10);
			
			
			
			JButton btnNewButton = new JButton("ADD DETAILS");
			btnNewButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if (e.getSource() == btnNewButton) {
						  String name;
				        
				           
				            int id;
				            id = Integer.parseInt(textField.getText());
				            name=textField_1.getText();
				           
				            try {
				            //System.out.println(userText);
				            	 PreparedStatement pstmt = con.prepareStatement("delete from jail where jailname=(?) and jailid=(?)");
				            	        pstmt.setInt(2, id);
				            	        pstmt.setString(1,  name);
				            	       
				            	       
				            	        int i=pstmt.executeUpdate();  
							    //txtmsg.append("\nInserted " + i + " rows successfully");
								JOptionPane.showMessageDialog(null, "\nDeleted " + i + " rows successfully");
					   }
				            catch(Exception E)
				            { System.out.println(E);}  
				}
				}
			});
			btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 16));
			btnNewButton.setBounds(116, 251, 189, 39);
			frame.getContentPane().add(btnNewButton);
			
			JButton btnNewButton_1 = new JButton("VIEW JAIL DETAILS");
			btnNewButton_1.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					 
					
							if (e.getSource() == btnNewButton_1) {	
							VIEWJAIL vj=new VIEWJAIL();
						
							}
						
					
				}
			});
			btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 16));
			btnNewButton_1.setBounds(402, 251, 224, 39);
			frame.getContentPane().add(btnNewButton_1);
			
			txtEditJail = new JTextField();
			txtEditJail.setFont(new Font("Tahoma", Font.BOLD, 16));
			txtEditJail.setText("EDIT JAIL");
			txtEditJail.setBounds(247, 10, 109, 30);
			frame.getContentPane().add(txtEditJail);
			txtEditJail.setColumns(10);
			
			
			frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		}
	}

 class VIEWJAIL {

		private JFrame frame;
		private JTable table;
	    String[][] tbl=new String[100][100];
	    Connection con;
		Statement stmt;
		ResultSet rs;
		private JLabel lblNewLabel;
		private JLabel lblNewLabel_2;
		/**
		 * Create the application.
		 */
		 VIEWJAIL() {
			try 
			{
				Class.forName("oracle.jdbc.driver.OracleDriver");
			} 
			catch (Exception e) 
			{
				System.err.println("Unable to find and load driver");
				System.exit(1);
			}
			connectToDB();
			initialize();
			this.frame.setVisible(true);
		}
		 void connectToDB() 
		    {
				try 
				{
				 con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","saikumar","sql");
				  stmt = con.createStatement();

				} 
				catch (SQLException connectException) 
				{
				  System.out.println(connectException.getMessage());
				  System.out.println(connectException.getSQLState());
				  System.out.println(connectException.getErrorCode());
				  System.exit(1);
				}
		    }
		/**
		 * Initialize the contents of the frame.
		 */
		private void initialize() {
			frame = new JFrame();
			frame.setBounds(100, 100, 797, 503);
			frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
			frame.getContentPane().setLayout(null);
			
			JTextPane txtpnOfficerDetails = new JTextPane();
			txtpnOfficerDetails.setFont(new Font("Tahoma", Font.BOLD, 21));
			txtpnOfficerDetails.setText("JAIL DETAILS");
			txtpnOfficerDetails.setBounds(227, 25, 239, 32);
			frame.getContentPane().add(txtpnOfficerDetails);
			try {
				ResultSet rs=stmt.executeQuery("select * from JAIL");
				
				int i=0;
				while(rs.next()) {
					
					//System.out.println(rs.getString(1)+" "+rs.getString(2)+" "+rs.getString(3));
					
					tbl[i][0]=rs.getString(1);
					tbl[i][1]=rs.getString(2);
					i=i+1;
					
				}
				/*for(int j=0;i<5;i++) {
				System.out.println(tbl[i][0]+" "+tbl[i][1]+" "+tbl[i][2]+" ");
				}*/
				
			
			table = new JTable();
			table.setRowSelectionAllowed(false);
			table.setSurrendersFocusOnKeystroke(true);
			table.setModel(new DefaultTableModel(
				tbl,
				new String[] {
					"OFFICER ID", "NAME"
				}
			));
			table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
			table.setBounds(29, 137, 723, 121);
			frame.getContentPane().add(table);
			
			lblNewLabel = new JLabel("JAILID");
			lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 17));
			lblNewLabel.setBounds(110, 101, 235, 26);
			frame.getContentPane().add(lblNewLabel);
			
			lblNewLabel_2 = new JLabel("JAIL NAME");
			lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 17));
			lblNewLabel_2.setBounds(476, 103, 229, 23);
			frame.getContentPane().add(lblNewLabel_2);
			}
			catch(Exception E)
	        { 
	        	System.out.println(E);
	        }  
			
			
		}
	}




import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTabbedPane;
import javax.swing.JPanel;
import javax.swing.JButton;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;
import java.awt.Image;

import javax.swing.JEditorPane;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import java.awt.Color;
import javax.swing.JTextPane;
import javax.swing.JTextArea;

public class main_frame {

	private JFrame frame;
	

	
	public main_frame() {
		initialize();
		this.frame.setVisible(true);
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setTitle("POLICE STATION DATABASE");
		frame.setBounds(100, 100, 675, 502);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane.setBounds(10, 39, 641, 416);
		frame.getContentPane().add(tabbedPane);
		
		JPanel panel = new JPanel();
		tabbedPane.addTab("Officer    ", null, panel, null);
		
		JButton btnNewButton = new JButton("ADD OFFICER");
		btnNewButton.setBounds(55, 69, 133, 39);
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 13));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (e.getSource() == btnNewButton) {
					ADDOFFICER addoff=new ADDOFFICER();
										
				}
			}
		});
		panel.setLayout(null);
		panel.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("EDIT OFFICER");
		btnNewButton_1.setBounds(55, 154, 133, 39);
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 13));
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (e.getSource() == btnNewButton_1) {
					EDITOFFICER editoff=new EDITOFFICER();
					
					
				}
				
			}
		});
		panel.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("DELETE OFFICER");
		btnNewButton_2.setBounds(55, 238, 151, 39);
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (e.getSource() == btnNewButton_2) {
					DELETEOFFICER deloff=new DELETEOFFICER();
					
				}
			}
		});
		btnNewButton_2.setFont(new Font("Tahoma", Font.BOLD, 13));
		panel.add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("VIEW OFFICERS");
		btnNewButton_3.setBounds(55, 321, 151, 39);
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (e.getSource() == btnNewButton_3) {
					VIEWOFFICER viewoff=new VIEWOFFICER();
				}
				
			}
		});
		btnNewButton_3.setFont(new Font("Tahoma", Font.BOLD, 13));
		panel.add(btnNewButton_3);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setBounds(296, 69, 271, 267);
		Image image=new ImageIcon(this.getClass().getResource("police.jpg")).getImage();
		lblNewLabel.setIcon(new ImageIcon(image));
		panel.add(lblNewLabel);
		
		JPanel panel_1 = new JPanel();
		tabbedPane.addTab("FIR   ", null, panel_1, null);
		panel_1.setLayout(null);
		
		JButton btnNewButton_4 = new JButton("ADD FIR");
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (e.getSource() == btnNewButton_4) {
					ADDFIR addfir=new ADDFIR();
				}
				
			}
		});
		btnNewButton_4.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnNewButton_4.setBounds(74, 53, 130, 27);
		panel_1.add(btnNewButton_4);
		
		JButton btnNewButton_5 = new JButton("EDIT FIR");
		btnNewButton_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (e.getSource() == btnNewButton_5) {
					EDITFIR editfir=new EDITFIR();
				}
				
			}
		});
		btnNewButton_5.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnNewButton_5.setBounds(74, 119, 130, 27);
		panel_1.add(btnNewButton_5);
		
		JButton btnNewButton_6 = new JButton("DELETE FIR");
		btnNewButton_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (e.getSource() == btnNewButton_6) {
					DELETEFIR delfir=new DELETEFIR();
				}
			}
		});
		btnNewButton_6.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnNewButton_6.setBounds(74, 197, 130, 27);
		panel_1.add(btnNewButton_6);
		
		JButton btnNewButton_7 = new JButton("VIEW FIR");
		btnNewButton_7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (e.getSource() == btnNewButton_7) {
					VIEWFIR viewfir=new VIEWFIR();
				}
			}
		});
		btnNewButton_7.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnNewButton_7.setBounds(74, 273, 130, 27);
		panel_1.add(btnNewButton_7);
		
		JLabel lblNewLabel_1 = new JLabel("");
		Image image1=new ImageIcon(this.getClass().getResource("FIR.jpg")).getImage();
		lblNewLabel_1.setIcon(new ImageIcon(image1));
		lblNewLabel_1.setBounds(270, 53, 314, 247);
		panel_1.add(lblNewLabel_1);
		
		JPanel panel_2 = new JPanel();
		tabbedPane.addTab("Thieves", null, panel_2, null);
		panel_2.setLayout(null);
		
		JButton btnNewButton_8 = new JButton("ADD THIEVES");
		btnNewButton_8.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (e.getSource() == btnNewButton_8) {
					ADDTHIEVES addthi=new ADDTHIEVES();
				}
				
			}
		});
		btnNewButton_8.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnNewButton_8.setBounds(88, 40, 146, 35);
		panel_2.add(btnNewButton_8);
		
		JButton btnNewButton_9 = new JButton("EDIT THIEVES");
		btnNewButton_9.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (e.getSource() == btnNewButton_9) {
					EDITTHIEVES EDITthi=new EDITTHIEVES();
				}
				
			}
		});
		btnNewButton_9.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnNewButton_9.setBounds(88, 129, 146, 35);
		panel_2.add(btnNewButton_9);
		
		JButton btnNewButton_10 = new JButton("DELETE THIEVES");
		btnNewButton_10.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (e.getSource() == btnNewButton_10) {
				   DELETETHIEVES delthi=new DELETETHIEVES();
				}
				
			}
		});
		btnNewButton_10.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnNewButton_10.setBounds(88, 229, 176, 35);
		panel_2.add(btnNewButton_10);
		
		JButton btnNewButton_11 = new JButton("VIEW THIEVES");
		btnNewButton_11.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (e.getSource() == btnNewButton_11) {
					   VIEWTHIEVES veiwthi=new VIEWTHIEVES();
					}
			}
		});
		btnNewButton_11.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnNewButton_11.setBounds(88, 319, 155, 35);
		panel_2.add(btnNewButton_11);
		
		JLabel lblNewLabel_2 = new JLabel("");
		Image image2=new ImageIcon(this.getClass().getResource("theive.jpg")).getImage();
		lblNewLabel_2.setIcon(new ImageIcon(image2));
		lblNewLabel_2.setBounds(288, 56, 275, 277);
		panel_2.add(lblNewLabel_2);
		
		JPanel panel_3 = new JPanel();
		tabbedPane.addTab("   Jail  ", null, panel_3, null);
		panel_3.setLayout(null);
		
		JButton btnNewButton_12 = new JButton("ADD JAIL");
		btnNewButton_12.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (e.getSource() == btnNewButton_12) {
					   ADDJAIL addjail=new ADDJAIL();
					}
			}
		});
		btnNewButton_12.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnNewButton_12.setBounds(69, 21, 106, 43);
		panel_3.add(btnNewButton_12);
		
		JButton btnNewButton_13 = new JButton("EDIT JAIL");
		btnNewButton_13.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (e.getSource() == btnNewButton_13) {
					   EDITJAIL editjail=new EDITJAIL();
					}
				
			}
		});
		btnNewButton_13.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnNewButton_13.setBounds(69, 116, 106, 43);
		panel_3.add(btnNewButton_13);
		
		JButton btnNewButton_14 = new JButton("DELETE JAIL");
		btnNewButton_14.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (e.getSource() == btnNewButton_14) {
					   DELETEJAIL DELjail=new DELETEJAIL();
					}
				
			}
		});
		btnNewButton_14.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnNewButton_14.setBounds(69, 200, 137, 43);
		panel_3.add(btnNewButton_14);
		
		JButton btnNewButton_15 = new JButton("VIEW JAIL");
		btnNewButton_15.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (e.getSource() == btnNewButton_15) {
					   VIEWJAIL viewjail=new VIEWJAIL();
					}
				
			}
		});
		btnNewButton_15.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnNewButton_15.setBounds(69, 293, 127, 43);
		panel_3.add(btnNewButton_15);
		
		JLabel lblNewLabel_3 = new JLabel("");
		Image image3=new ImageIcon(this.getClass().getResource("jail.jpg")).getImage();
		lblNewLabel_3.setIcon(new ImageIcon(image3));
		lblNewLabel_3.setBounds(242, 63, 345, 258);
		panel_3.add(lblNewLabel_3);
		
		JPanel panel_4 = new JPanel();
		tabbedPane.addTab("Compond Views", null, panel_4, null);
		panel_4.setLayout(null);
		
		JTextArea txtrWhichOfficerHandled = new JTextArea();
		txtrWhichOfficerHandled.setBackground(Color.CYAN);
		txtrWhichOfficerHandled.setFont(new Font("Monospaced", Font.BOLD | Font.ITALIC, 17));
		txtrWhichOfficerHandled.setText("OFFICER-handle-FIR");
		txtrWhichOfficerHandled.setBounds(53, 58, 198, 27);
		panel_4.add(txtrWhichOfficerHandled);
		
		JButton btnNewButton_16 = new JButton("VIEW");
		btnNewButton_16.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if (e.getSource() == btnNewButton_16) {
					   OFFICERANDFIR OF=new OFFICERANDFIR();
					}
				
			}
		});
		btnNewButton_16.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnNewButton_16.setBounds(311, 59, 105, 27);
		panel_4.add(btnNewButton_16);
		
		JButton btnNewButton_17 = new JButton("VIEW");
		btnNewButton_17.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (e.getSource() == btnNewButton_17) {
					   OFFICERANDJAIL OFT=new OFFICERANDJAIL();
					}
				
				
			}
		});
		btnNewButton_17.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnNewButton_17.setBounds(330, 241, 95, 26);
		panel_4.add(btnNewButton_17);
		
		JTextArea txtrWhichThiefWent = new JTextArea();
		txtrWhichThiefWent.setBackground(Color.GREEN);
		txtrWhichThiefWent.setFont(new Font("Monospaced", Font.BOLD | Font.ITALIC, 16));
		txtrWhichThiefWent.setText("Thief-went-JAIL");
		txtrWhichThiefWent.setBounds(53, 241, 168, 29);
		panel_4.add(txtrWhichThiefWent);
		
		
		
		JTextPane txtpnWelcomeToPolice = new JTextPane();
		txtpnWelcomeToPolice.setBounds(108, 10, 399, 26);
		txtpnWelcomeToPolice.setBackground(Color.ORANGE);
		txtpnWelcomeToPolice.setForeground(Color.BLACK);
		txtpnWelcomeToPolice.setFont(new Font("Tahoma", Font.BOLD, 16));
		txtpnWelcomeToPolice.setText("WELCOME TO POLICE STATION DATABASE");
		frame.getContentPane().add(txtpnWelcomeToPolice);
	}
}

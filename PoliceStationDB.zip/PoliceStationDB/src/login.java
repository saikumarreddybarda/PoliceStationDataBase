import java.awt.EventQueue;
import javax.swing.JOptionPane;
import javax.swing.JFrame;
import javax.swing.JTextArea;
import java.awt.BorderLayout;
import javax.swing.JTextPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import java.awt.Color;
import java.awt.Font;
import javax.swing.JLabel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import javax.swing.JPasswordField;

public class login{

	private JFrame frame;
	private JTextField textField;
	private JLabel lblNewLabel_1;
	private JButton btnNewButton;
	main_frame mf;
	private JPasswordField passwordField;
	Connection con;
	Statement stmt;
	ResultSet rs;

	

	/**
	 * Create the application.
	 */
	public login() {
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
		initialize();
		this.frame.setVisible(true);
	}
	public void connectToDB() 
    {
		try 
		{
		 con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","saikumar","sql");
		  stmt = con.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 805, 496);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JTextArea textArea = new JTextArea("LOGIN FORM");
		textArea.setFont(new Font("Monospaced", Font.BOLD, 20));
		textArea.setBackground(Color.GREEN);
		textArea.setBounds(267, 88, 139, 31);
		frame.getContentPane().add(textArea);
		
		textField = new JTextField();
		textField.setBounds(297, 183, 178, 31);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("OFFICER NAME");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblNewLabel.setBounds(157, 181, 144, 31);
		frame.getContentPane().add(lblNewLabel);
		
		lblNewLabel_1 = new JLabel("PASSWORD");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblNewLabel_1.setBounds(157, 260, 135, 29);
		frame.getContentPane().add(lblNewLabel_1);
		
		btnNewButton = new JButton("LOGIN");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (e.getSource() == btnNewButton) {
		            String userText;
		            String pwdText;
		            userText = textField.getText();
		            pwdText = passwordField.getText();
		            try {
		            //System.out.println(userText);
		            rs = stmt.executeQuery("SELECT * FROM userdetails ");
		            while(rs.next()) {
		       
		            	if(rs.getString(2).equals(userText) && rs.getString(3).equals(pwdText)) {
		            		  mf=new main_frame();
			                  frame.dispose();
			                  break;
		            	}
		            }
		            if(!rs.next()) {
		            	JOptionPane.showMessageDialog(null, "Invalid Username or Password");
		            }
		            
		            }
		            catch(Exception E)
		            { System.out.println(E);}  
		}
			}
		});
		btnNewButton.setBounds(259, 352, 173, 37);
		frame.getContentPane().add(btnNewButton);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(297, 260, 177, 29);
		frame.getContentPane().add(passwordField);
		
		JTextArea txtrDoYouWant = new JTextArea();
		txtrDoYouWant.setEditable(false);
		txtrDoYouWant.setFont(new Font("Monospaced", Font.ITALIC, 15));
		txtrDoYouWant.setText("Do you want Enter into POLICE STATION DATABASE? Please login");
		txtrDoYouWant.setBackground(Color.CYAN);
		txtrDoYouWant.setBounds(37, 10, 635, 31);
		frame.getContentPane().add(txtrDoYouWant);
	}
}

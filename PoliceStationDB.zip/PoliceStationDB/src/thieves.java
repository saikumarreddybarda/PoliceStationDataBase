import java.awt.Color;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableModel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.PreparedStatement;
import java.awt.event.ActionEvent;

 class ADDTHIEVES {

	private JFrame frame;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	Connection con;
	Statement stmt;
	ResultSet rs;

	/**
	 * Create the application.
	 */
	public ADDTHIEVES() {
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
		initialize();
		this.frame.setVisible(true);
	}
    void connectToDB() 
    {
		try 
		{
		 con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","saikumar","sql");
		  stmt = con.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 926, 506);
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("THIEVES ID");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblNewLabel.setBounds(132, 72, 165, 32);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("NAME OF THE THIEVES");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblNewLabel_1.setBounds(61, 147, 217, 32);
		frame.getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("REASON");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblNewLabel_2.setBounds(185, 241, 177, 39);
		frame.getContentPane().add(lblNewLabel_2);
		
		textField = new JTextField();
		textField.setBounds(299, 77, 189, 28);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setBounds(299, 147, 189, 28);
		frame.getContentPane().add(textField_1);
		textField_1.setColumns(10);
		
		textField_2 = new JTextField();
		textField_2.setBounds(310, 247, 190, 31);
		frame.getContentPane().add(textField_2);
		textField_2.setColumns(10);
		
		JButton btnNewButton = new JButton("ADD DETAILS");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (e.getSource() == btnNewButton) {
					  String name;
			           String reason;
			           
			            int id;
			            id = Integer.parseInt(textField.getText());
			            name=textField_1.getText();
			            reason=textField_2.getText();
			            try {
			            //System.out.println(userText);
			            	 PreparedStatement pstmt = con.prepareStatement("insert into THIEVES(thievesid,name,reason) values (?,?,?)");
			            	        pstmt.setInt(1, id);
			            	        pstmt.setString(2,  name);
			            	        pstmt.setString(3, reason);
			            	       
			            	        int i=pstmt.executeUpdate();  
						    //txtmsg.append("\nInserted " + i + " rows successfully");
							JOptionPane.showMessageDialog(null, "\nInserted " + i + " rows successfully");
				   }
			            catch(Exception E)
			            { System.out.println(E);}  
			}
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 16));
		btnNewButton.setBounds(227, 344, 189, 39);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("clear");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				  if (e.getSource() == btnNewButton_1) {
					  textField.setText("");
					  textField_1.setText("");
					  textField_2.setText("");
					  
			        }
			}
		});
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 16));
		btnNewButton_1.setBounds(489, 344, 120, 39);
		frame.getContentPane().add(btnNewButton_1);
		
		
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}

 class DELETETHIEVES {

		private JFrame frame;
		private JTextField textField;
		private JTextField textField_1;
		private JTextField textField_2;
		Connection con;
		Statement stmt;
		ResultSet rs;
		/**
		 * Create the application.
		 */
		public DELETETHIEVES() {
			try 
			{
				Class.forName("oracle.jdbc.driver.OracleDriver");
			} 
			catch (Exception e) 
			{
				System.err.println("Unable to find and load driver");
				System.exit(1);
			}
			connectToDB();
			initialize();
			this.frame.setVisible(true);
		}
		 void connectToDB() 
		    {
				try 
				{
				 con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","saikumar","sql");
				  stmt = con.createStatement();

				} 
				catch (SQLException connectException) 
				{
				  System.out.println(connectException.getMessage());
				  System.out.println(connectException.getSQLState());
				  System.out.println(connectException.getErrorCode());
				  System.exit(1);
				}
		    }
		/**
		 * Initialize the contents of the frame.
		 */
		private void initialize() {
			frame = new JFrame();
			frame.setBounds(100, 100, 854, 505);
			frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
			frame.getContentPane().setLayout(null);
			
			JLabel lblNewLabel = new JLabel("THIEVES ID");
			lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 16));
			lblNewLabel.setBounds(139, 117, 114, 38);
			frame.getContentPane().add(lblNewLabel);
			
			JLabel lblNewLabel_1 = new JLabel("NAME");
			lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 16));
			lblNewLabel_1.setBounds(143, 231, 181, 29);
			frame.getContentPane().add(lblNewLabel_1);
			
			JLabel lblNewLabel_2 = new JLabel("REASON");
			lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 17));
			lblNewLabel_2.setBounds(143, 292, 166, 29);
			frame.getContentPane().add(lblNewLabel_2);
			
			textField = new JTextField();
			textField.setBounds(311, 124, 96, 29);
			frame.getContentPane().add(textField);
			textField.setColumns(10);
			
			textField_1 = new JTextField();
			textField_1.setBounds(291, 235, 139, 26);
			frame.getContentPane().add(textField_1);
			textField_1.setColumns(10);
			
			textField_2 = new JTextField();
			textField_2.setBounds(291, 296, 139, 27);
			frame.getContentPane().add(textField_2);
			textField_2.setColumns(10);
			
			JButton btnNewButton = new JButton("DELETE");
			btnNewButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if (e.getSource() == btnNewButton) {
						  String name;
				           String reason;
				       
				            int id;
				            id = Integer.parseInt(textField.getText());
				            name=textField_1.getText();
				            reason=textField_2.getText();
				            try {
				            //System.out.println(userText);
				            	 PreparedStatement pstmt = con.prepareStatement("delete from thieves where name=(?),reason=(?) where thievesid=(?)");
				            	        pstmt.setInt(3, id);
				            	        pstmt.setString(1,  name);
				            	        pstmt.setString(2, reason);
				            	       
				            	        int i=pstmt.executeUpdate();  
							    //txtmsg.append("\nInserted " + i + " rows successfully");
								JOptionPane.showMessageDialog(null, "\nDeleted " + i + " rows successfully");
					   }
				            catch(Exception E)
				            { System.out.println(E);}  
				}
				
				}
			});
			btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 16));
			btnNewButton.setBounds(143, 394, 104, 38);
			frame.getContentPane().add(btnNewButton);
			
			JButton btnNewButton_1 = new JButton("VIEW THIEVES DETAILS");
			btnNewButton_1.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if (e.getSource() == btnNewButton_1) {	
					  VIEWTHIEVES vt=new VIEWTHIEVES();
					}
				}
			});
			btnNewButton_1.setFont(new Font("Tahoma", Font.PLAIN, 15));
			btnNewButton_1.setBounds(370, 394, 215, 38);
			frame.getContentPane().add(btnNewButton_1);
			
			JTextArea txtrMandotory = new JTextArea();
			txtrMandotory.setBackground(new Color(255, 255, 255));
			txtrMandotory.setFont(new Font("Monospaced", Font.PLAIN, 17));
			txtrMandotory.setText("Id is Mandotory!");
			txtrMandotory.setBounds(114, 165, 205, 29);
			frame.getContentPane().add(txtrMandotory);
			
			JLabel lblNewLabel_3 = new JLabel("DELETE THIEVES");
			lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 18));
			lblNewLabel_3.setBounds(228, 35, 179, 29);
			frame.getContentPane().add(lblNewLabel_3);
		}
	}

 class EDITTHIEVES {

		private JFrame frame;
		private JTextField textField;
		private JTextField textField_1;
		private JTextField textField_2;
		Connection con;
		Statement stmt;
		ResultSet rs;
		/**
		 * Create the application.
		 */
		public EDITTHIEVES() {
			try 
			{
				Class.forName("oracle.jdbc.driver.OracleDriver");
			} 
			catch (Exception e) 
			{
				System.err.println("Unable to find and load driver");
				System.exit(1);
			}
			connectToDB();
			initialize();
			this.frame.setVisible(true);
		}
		 void connectToDB() 
		    {
				try 
				{
				 con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","saikumar","sql");
				  stmt = con.createStatement();

				} 
				catch (SQLException connectException) 
				{
				  System.out.println(connectException.getMessage());
				  System.out.println(connectException.getSQLState());
				  System.out.println(connectException.getErrorCode());
				  System.exit(1);
				}
		    }
		/**
		 * Initialize the contents of the frame.
		 */
		private void initialize() {
			frame = new JFrame();
			frame.setBounds(100, 100, 854, 505);
			frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
			frame.getContentPane().setLayout(null);
			
			JLabel lblNewLabel = new JLabel("THIEVES ID");
			lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 16));
			lblNewLabel.setBounds(139, 117, 114, 38);
			frame.getContentPane().add(lblNewLabel);
			
			JLabel lblNewLabel_1 = new JLabel("NAME");
			lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 16));
			lblNewLabel_1.setBounds(143, 231, 181, 29);
			frame.getContentPane().add(lblNewLabel_1);
			
			JLabel lblNewLabel_2 = new JLabel("REASON");
			lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 17));
			lblNewLabel_2.setBounds(143, 292, 166, 29);
			frame.getContentPane().add(lblNewLabel_2);
			
			textField = new JTextField();
			textField.setBounds(311, 124, 96, 29);
			frame.getContentPane().add(textField);
			textField.setColumns(10);
			
			textField_1 = new JTextField();
			textField_1.setBounds(291, 235, 139, 26);
			frame.getContentPane().add(textField_1);
			textField_1.setColumns(10);
			
			textField_2 = new JTextField();
			textField_2.setBounds(291, 296, 139, 27);
			frame.getContentPane().add(textField_2);
			textField_2.setColumns(10);
			
			JButton btnNewButton = new JButton("EDIT");
			btnNewButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if (e.getSource() == btnNewButton) {
						  String name;
				           String reason;
				       
				            int id;
				            id = Integer.parseInt(textField.getText());
				            name=textField_1.getText();
				            reason=textField_2.getText();
				            try {
				            //System.out.println(userText);
				            	 PreparedStatement pstmt = con.prepareStatement("update thieves set name=(?),reason=(?) where thievesid=(?)");
				            	        pstmt.setInt(3, id);
				            	        pstmt.setString(1,  name);
				            	        pstmt.setString(2, reason);
				            	       
				            	        int i=pstmt.executeUpdate();  
							    //txtmsg.append("\nInserted " + i + " rows successfully");
								JOptionPane.showMessageDialog(null, "\nInserted " + i + " rows successfully");
					   }
				            catch(Exception E)
				            { System.out.println(E);}  
				}
				
				}
			});
			btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 16));
			btnNewButton.setBounds(143, 394, 104, 38);
			frame.getContentPane().add(btnNewButton);
			
			JButton btnNewButton_1 = new JButton("VIEW THIEVES DETAILS");
			btnNewButton_1.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if (e.getSource() == btnNewButton_1) {	
					  VIEWTHIEVES vt=new VIEWTHIEVES();
					}
				}
			});
			btnNewButton_1.setFont(new Font("Tahoma", Font.PLAIN, 15));
			btnNewButton_1.setBounds(370, 394, 215, 38);
			frame.getContentPane().add(btnNewButton_1);
			
			JTextArea txtrMandotory = new JTextArea();
			txtrMandotory.setBackground(new Color(255, 255, 255));
			txtrMandotory.setFont(new Font("Monospaced", Font.PLAIN, 17));
			txtrMandotory.setText("Id is Mandotory!");
			txtrMandotory.setBounds(114, 165, 205, 29);
			frame.getContentPane().add(txtrMandotory);
			
			JLabel lblNewLabel_3 = new JLabel("EDIT THIEVES");
			lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 18));
			lblNewLabel_3.setBounds(228, 35, 179, 29);
			frame.getContentPane().add(lblNewLabel_3);
		}
	}
 class VIEWTHIEVES {

		private JFrame frame;
		private JTable table;
	    String[][] tbl=new String[100][100];
	    Connection con;
		Statement stmt;
		ResultSet rs;
		private JLabel lblNewLabel;
		private JLabel lblNewLabel_1;
		private JLabel lblNewLabel_3;
		/**
		 * Create the application.
		 */
		 VIEWTHIEVES() {
			try 
			{
				Class.forName("oracle.jdbc.driver.OracleDriver");
			} 
			catch (Exception e) 
			{
				System.err.println("Unable to find and load driver");
				System.exit(1);
			}
			connectToDB();
			initialize();
			this.frame.setVisible(true);
		}
		 void connectToDB() 
		    {
				try 
				{
				 con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","saikumar","sql");
				  stmt = con.createStatement();

				} 
				catch (SQLException connectException) 
				{
				  System.out.println(connectException.getMessage());
				  System.out.println(connectException.getSQLState());
				  System.out.println(connectException.getErrorCode());
				  System.exit(1);
				}
		    }
		/**
		 * Initialize the contents of the frame.
		 */
		private void initialize() {
			frame = new JFrame();
			frame.setBounds(100, 100, 797, 503);
			frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
			frame.getContentPane().setLayout(null);
			
			JTextPane txtpnOfficerDetails = new JTextPane();
			txtpnOfficerDetails.setFont(new Font("Tahoma", Font.BOLD, 21));
			txtpnOfficerDetails.setText("THIEVES DETAILS");
			txtpnOfficerDetails.setBounds(227, 25, 239, 32);
			frame.getContentPane().add(txtpnOfficerDetails);
			try {
				ResultSet rs=stmt.executeQuery("select * from THIEVES");
				
				int i=0;
				while(rs.next()) {
					
					
					
					tbl[i][0]=rs.getString(1);
					tbl[i][1]=rs.getString(2);
					tbl[i][2]=rs.getString(3); 
				
					i=i+1;
					
				}
				
				
			
			table = new JTable();
			table.setRowSelectionAllowed(false);
			table.setSurrendersFocusOnKeystroke(true);
			table.setModel(new DefaultTableModel(
				tbl,
				new String[] {
					"OFFICER ID", "NAME", "PHONENO"
				}
			));
			table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
			table.setBounds(29, 137, 723, 121);
			frame.getContentPane().add(table);
			
			lblNewLabel = new JLabel("THIEVES ID");
			lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 17));
			lblNewLabel.setBounds(48, 101, 235, 26);
			frame.getContentPane().add(lblNewLabel);
			
			lblNewLabel_1 = new JLabel("NAME ");
			lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 17));
			lblNewLabel_1.setBounds(311, 92, 199, 45);
			frame.getContentPane().add(lblNewLabel_1);
			
			lblNewLabel_3 = new JLabel("REASON");
			lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 17));
			lblNewLabel_3.setBounds(541, 101, 164, 26);
			frame.getContentPane().add(lblNewLabel_3);
			}
			catch(Exception E)
	        { 
	        	System.out.println(E);
	        }  
			
			
		}
	}

 
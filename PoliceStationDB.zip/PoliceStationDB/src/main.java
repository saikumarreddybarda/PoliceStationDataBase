
public class main {

	public static void main(String[] args) {
		try {
			login window = new login();
			
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}

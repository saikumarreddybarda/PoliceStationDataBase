import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableModel;

 class ADDOFFICER {

	private JFrame frame;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	Connection con;
	Statement stmt;
	ResultSet rs;

	/**
	 * Create the application.
	 */
	public ADDOFFICER() {
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
		initialize();
		this.frame.setVisible(true);
	}
    void connectToDB() 
    {
		try 
		{
		 con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","saikumar","sql");
		  stmt = con.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 926, 506);
		//frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("OFFICER ID");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblNewLabel.setBounds(103, 101, 165, 32);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("OFFICER NAME");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblNewLabel_1.setBounds(103, 185, 165, 32);
		frame.getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("PHONENO");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblNewLabel_2.setBounds(103, 259, 128, 39);
		frame.getContentPane().add(lblNewLabel_2);
		
		textField = new JTextField();
		textField.setBounds(299, 101, 189, 28);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setBounds(299, 185, 189, 28);
		frame.getContentPane().add(textField_1);
		textField_1.setColumns(10);
		
		textField_2 = new JTextField();
		textField_2.setBounds(298, 259, 190, 31);
		frame.getContentPane().add(textField_2);
		textField_2.setColumns(10);
		
		JButton btnNewButton = new JButton("ADD DETAILS");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (e.getSource() == btnNewButton) {
					  String name;
			            int phoneno;
			            int id;
			            id = Integer.parseInt(textField.getText());
			            phoneno=Integer.parseInt(textField_2.getText());
			            name=textField_1.getText();
			            try {
			            //System.out.println(userText);
			            	 PreparedStatement pstmt = con.prepareStatement("insert into officer(officerid,name,phoneno) values (?,?,?)");
			            	        pstmt.setInt(1, id);
			            	        pstmt.setString(2, name);
			            	        pstmt.setInt(3, phoneno);
			            	        int i=pstmt.executeUpdate();  
						    //txtmsg.append("\nInserted " + i + " rows successfully");
							JOptionPane.showMessageDialog(null, "\nInserted " + i + " rows successfully");
				   }
			            catch(Exception E)
			            { System.out.println(E);}  
			}
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 16));
		btnNewButton.setBounds(227, 344, 189, 39);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("clear");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				  if (e.getSource() == btnNewButton_1) {
					  textField.setText("");
					  textField_1.setText("");
					  textField_2.setText("");
			        }
			}
		});
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 16));
		btnNewButton_1.setBounds(489, 344, 120, 39);
		frame.getContentPane().add(btnNewButton_1);
		
		JTextArea txtrAddOfficer = new JTextArea();
		txtrAddOfficer.setBackground(Color.ORANGE);
		txtrAddOfficer.setFont(new Font("Monospaced", Font.BOLD, 19));
		txtrAddOfficer.setText("ADD OFFICER");
		txtrAddOfficer.setBounds(294, 10, 146, 39);
		frame.getContentPane().add(txtrAddOfficer);
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	}
}
 
 class DELETEOFFICER {

		private JFrame frame;
		private JTextField textField;
		private JTextField textField_1;
		private JTextField textField_2;
		Connection con;
		Statement stmt;
		ResultSet rs;
		/**
		 * Create the application.
		 */
		public DELETEOFFICER() {
			try 
			{
				Class.forName("oracle.jdbc.driver.OracleDriver");
			} 
			catch (Exception e) 
			{
				System.err.println("Unable to find and load driver");
				System.exit(1);
			}
			connectToDB();
			initialize();
			this.frame.setVisible(true);
		}
		 void connectToDB() 
		    {
				try 
				{
				 con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","saikumar","sql");
				  stmt = con.createStatement();

				} 
				catch (SQLException connectException) 
				{
				  System.out.println(connectException.getMessage());
				  System.out.println(connectException.getSQLState());
				  System.out.println(connectException.getErrorCode());
				  System.exit(1);
				}
		    }
		/**
		 * Initialize the contents of the frame.
		 */
		private void initialize() {
			frame = new JFrame();
			frame.setBounds(100, 100, 854, 505);
			frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
			frame.getContentPane().setLayout(null);
			
			JLabel lblNewLabel = new JLabel("ID");
			lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 16));
			lblNewLabel.setBounds(177, 130, 45, 38);
			frame.getContentPane().add(lblNewLabel);
			
			JLabel lblNewLabel_1 = new JLabel("Name");
			lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 16));
			lblNewLabel_1.setBounds(168, 218, 139, 29);
			frame.getContentPane().add(lblNewLabel_1);
			
			JLabel lblNewLabel_2 = new JLabel("Phone No");
			lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 17));
			lblNewLabel_2.setBounds(160, 283, 130, 29);
			frame.getContentPane().add(lblNewLabel_2);
			
			textField = new JTextField();
			textField.setBounds(268, 132, 96, 29);
			frame.getContentPane().add(textField);
			textField.setColumns(10);
			
			textField_1 = new JTextField();
			textField_1.setBounds(268, 218, 139, 26);
			frame.getContentPane().add(textField_1);
			textField_1.setColumns(10);
			
			textField_2 = new JTextField();
			textField_2.setBounds(268, 283, 139, 27);
			frame.getContentPane().add(textField_2);
			textField_2.setColumns(10);
			
			JButton btnNewButton = new JButton("DELETE");
			btnNewButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					
					if (e.getSource() == btnNewButton) {
						try {
						  String name;
				            int phoneno;
				            int id;
				            id = Integer.parseInt(textField.getText());
				            phoneno=Integer.parseInt(textField_2.getText());
				            name=textField_1.getText();   
				            	
				               
				            	 PreparedStatement pstmt = con.prepareStatement("delete from officer where name=(?)and phoneno=(?) and officerid=(?)");
				            	        pstmt.setInt(3, id);
				            	        pstmt.setString(1, name);
				            	        pstmt.setInt(2, phoneno);
				            	        int i=pstmt.executeUpdate();  
							    //txtmsg.append("\nInserted " + i + " rows successfully");
								JOptionPane.showMessageDialog(null, "\nDeleted " + i + " rows successfully");
				          }
				               
				            catch(Exception E)
				            { 
				            	JOptionPane.showMessageDialog(null, "Check the details");
				            	System.out.println(E);
				            }  
				}
					
					
					
				}
					
			});
			btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 16));
			btnNewButton.setBounds(160, 356, 104, 38);
			frame.getContentPane().add(btnNewButton);
			
			JButton btnNewButton_1 = new JButton("VIEW OFFICER DETAILS");
			btnNewButton_1.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if (e.getSource() == btnNewButton_1) {	
					VIEWOFFICER vf=new VIEWOFFICER();
					}
				}
			});
			btnNewButton_1.setFont(new Font("Tahoma", Font.PLAIN, 15));
			btnNewButton_1.setBounds(342, 356, 226, 38);
			frame.getContentPane().add(btnNewButton_1);
			
			JTextArea txtrMandotory = new JTextArea();
			txtrMandotory.setBackground(new Color(255, 255, 255));
			txtrMandotory.setFont(new Font("Monospaced", Font.PLAIN, 17));
			txtrMandotory.setText("Id is Mandotory!");
			txtrMandotory.setBounds(177, 178, 205, 29);
			frame.getContentPane().add(txtrMandotory);
			
			JLabel lblNewLabel_3 = new JLabel("DELETE OFFICER");
			lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 18));
			lblNewLabel_3.setBounds(228, 35, 179, 29);
			frame.getContentPane().add(lblNewLabel_3);
		}
	}

 class EDITOFFICER {

	private JFrame frame;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	Connection con;
	Statement stmt;
	ResultSet rs;
	/**
	 * Create the application.
	 */
	public EDITOFFICER() {
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
		initialize();
		this.frame.setVisible(true);
	}
	 void connectToDB() 
	    {
			try 
			{
			 con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","saikumar","sql");
			  stmt = con.createStatement();

			} 
			catch (SQLException connectException) 
			{
			  System.out.println(connectException.getMessage());
			  System.out.println(connectException.getSQLState());
			  System.out.println(connectException.getErrorCode());
			  System.exit(1);
			}
	    }
	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 854, 505);
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("ID");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblNewLabel.setBounds(177, 130, 45, 38);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Name");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblNewLabel_1.setBounds(168, 218, 139, 29);
		frame.getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Phone No");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 17));
		lblNewLabel_2.setBounds(160, 283, 130, 29);
		frame.getContentPane().add(lblNewLabel_2);
		
		textField = new JTextField();
		textField.setBounds(268, 132, 96, 29);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setBounds(268, 218, 139, 26);
		frame.getContentPane().add(textField_1);
		textField_1.setColumns(10);
		
		textField_2 = new JTextField();
		textField_2.setBounds(268, 283, 139, 27);
		frame.getContentPane().add(textField_2);
		textField_2.setColumns(10);
		
		JButton btnNewButton = new JButton("EDIT");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (e.getSource() == btnNewButton) {
					try {
					  String name;
			            int phoneno;
			            int id;
			            id = Integer.parseInt(textField.getText());
			            phoneno=Integer.parseInt(textField_2.getText());
			            name=textField_1.getText();
			            
			           
			            	 PreparedStatement pstmt = con.prepareStatement("update officer set name=(?),phoneno=(?) where officerid=(?)");
			            	        pstmt.setInt(3, id);
			            	        pstmt.setString(1, name);
			            	        pstmt.setInt(2, phoneno);
			            	        int i=pstmt.executeUpdate();  
						    //txtmsg.append("\nInserted " + i + " rows successfully");
							JOptionPane.showMessageDialog(null, "\nUpdated " + i + " rows successfully");
				   }
			            catch(Exception E)
			            { 
			            	JOptionPane.showMessageDialog(null, "Check the details");
			            	System.out.println(E);
			            }  
			}
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 16));
		btnNewButton.setBounds(160, 356, 104, 38);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("VIEW OFFICER DETAILS");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (e.getSource() == btnNewButton_1) {	
				VIEWOFFICER vf=new VIEWOFFICER();
				}
			}
		});
		btnNewButton_1.setFont(new Font("Tahoma", Font.PLAIN, 15));
		btnNewButton_1.setBounds(342, 356, 226, 38);
		frame.getContentPane().add(btnNewButton_1);
		
		JTextArea txtrMandotory = new JTextArea();
		txtrMandotory.setBackground(new Color(255, 255, 255));
		txtrMandotory.setFont(new Font("Monospaced", Font.PLAIN, 17));
		txtrMandotory.setText("Id is Mandotory!");
		txtrMandotory.setBounds(177, 178, 205, 29);
		frame.getContentPane().add(txtrMandotory);
		
		JLabel lblNewLabel_3 = new JLabel("EDIT OFFICER");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel_3.setBounds(228, 35, 179, 29);
		frame.getContentPane().add(lblNewLabel_3);
	}
}

 class VIEWOFFICER {

		private JFrame frame;
		private JTable table;
	    String[][] tbl=new String[100][100];
	    Connection con;
		Statement stmt;
		ResultSet rs;
		private JLabel lblNewLabel;
		private JLabel lblNewLabel_1;
		private JLabel lblNewLabel_2;
		/**
		 * Create the application.
		 */
		 VIEWOFFICER() {
			try 
			{
				Class.forName("oracle.jdbc.driver.OracleDriver");
			} 
			catch (Exception e) 
			{
				System.err.println("Unable to find and load driver");
				System.exit(1);
			}
			connectToDB();
			initialize();
			this.frame.setVisible(true);
		}
		 void connectToDB() 
		    {
				try 
				{
				 con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","saikumar","sql");
				  stmt = con.createStatement();

				} 
				catch (SQLException connectException) 
				{
				  System.out.println(connectException.getMessage());
				  System.out.println(connectException.getSQLState());
				  System.out.println(connectException.getErrorCode());
				  System.exit(1);
				}
		    }
		/**
		 * Initialize the contents of the frame.
		 */
		private void initialize() {
			frame = new JFrame();
			frame.setBounds(100, 100, 797, 503);
			frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
			frame.getContentPane().setLayout(null);
			
			JTextPane txtpnOfficerDetails = new JTextPane();
			txtpnOfficerDetails.setFont(new Font("Tahoma", Font.BOLD, 21));
			txtpnOfficerDetails.setText("OFFICER DETAILS");
			txtpnOfficerDetails.setBounds(140, 23, 239, 32);
			frame.getContentPane().add(txtpnOfficerDetails);
			try {
				ResultSet rs=stmt.executeQuery("select * from officer");
				//ResultSet count=stmt.executeQuery("select count(*) from officer");
				int i=0;
				while(rs.next()) {
					
					//System.out.println(rs.getString(1)+" "+rs.getString(2)+" "+rs.getString(3));
					
					tbl[i][0]=rs.getString(1);
					tbl[i][1]=rs.getString(2);
					tbl[i][2]=rs.getString(3); 
					i=i+1;
					
				}
				for(int j=0;i<5;i++) {
				System.out.println(tbl[i][0]+" "+tbl[i][1]+" "+tbl[i][2]+" ");
				}
				
			
			table = new JTable();
			table.setRowSelectionAllowed(false);
			table.setSurrendersFocusOnKeystroke(true);
			table.setModel(new DefaultTableModel(
				tbl,
				new String[] {
					"OFFICER ID", "NAME", "PHONENO"
				}
			));
			table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
			table.setBounds(29, 137, 723, 121);
			frame.getContentPane().add(table);
			
			lblNewLabel = new JLabel("OfficerID");
			lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 17));
			lblNewLabel.setBounds(83, 98, 235, 26);
			frame.getContentPane().add(lblNewLabel);
			
			lblNewLabel_1 = new JLabel("Name");
			lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 17));
			lblNewLabel_1.setBounds(315, 98, 160, 23);
			frame.getContentPane().add(lblNewLabel_1);
			
			lblNewLabel_2 = new JLabel("Phone no");
			lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 17));
			lblNewLabel_2.setBounds(560, 98, 128, 23);
			frame.getContentPane().add(lblNewLabel_2);
			}
			catch(Exception E)
	        { 
	        	System.out.println(E);
	        }  
			
			
		}
	}


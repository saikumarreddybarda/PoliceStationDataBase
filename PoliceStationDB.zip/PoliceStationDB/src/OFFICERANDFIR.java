import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTextPane;
import java.awt.Font;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableModel;
import javax.swing.JLabel;
import java.awt.Color;

public class OFFICERANDFIR {

	private JFrame frame;
	private JTable table;
    String[][] tbl=new String[100][100];
    Connection con;
	Statement stmt;
	ResultSet rs;
	private JLabel lblNewLabel_1;
	private JLabel lblNewLabel_2;
	private JLabel lblNewLabel_3;
	/**
	 * Create the application.
	 */
	OFFICERANDFIR() {
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
		initialize();
		this.frame.setVisible(true);
	}
	 void connectToDB() 
	    {
			try 
			{
			 con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","saikumar","sql");
			  stmt = con.createStatement();

			} 
			catch (SQLException connectException) 
			{
			  System.out.println(connectException.getMessage());
			  System.out.println(connectException.getSQLState());
			  System.out.println(connectException.getErrorCode());
			  System.exit(1);
			}
	    }
	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 1072, 512);
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JTextPane txtpnOfficerDetails = new JTextPane();
		txtpnOfficerDetails.setBackground(Color.ORANGE);
		txtpnOfficerDetails.setFont(new Font("Tahoma", Font.BOLD, 21));
		txtpnOfficerDetails.setText("OFFICER & FIR DETAILS");
		txtpnOfficerDetails.setBounds(227, 25, 269, 32);
		frame.getContentPane().add(txtpnOfficerDetails);
		try {
			ResultSet rs=stmt.executeQuery("select o.name,o.phoneno,f.NAMEOFINFORMER,f.NAMEOFCRIMINAL,f.DESCRIPTIONOFOFFENCE from officer o,FIR f,handle h where o.OFFICERID=h.OFFICERID and h.FIRID=f.FIRID");
			
			int i=0;
			while(rs.next()) {
				
		
				
				tbl[i][0]=rs.getString(1);
				tbl[i][1]=rs.getString(2);
				tbl[i][2]=rs.getString(3); 
				tbl[i][3]=rs.getString(4); 
				tbl[i][4]=rs.getString(5); 
				i=i+1;
				
			}
			
			
		
		table = new JTable();
		table.setRowSelectionAllowed(false);
		table.setSurrendersFocusOnKeystroke(true);
		table.setModel(new DefaultTableModel(
			tbl,
			new String[] {
				"OFFICER ID", "NAME", "PHONENO", "New column", "New column"
			}
		));
		table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		table.setBounds(29, 137, 1019, 121);
		frame.getContentPane().add(table);
		
		lblNewLabel_1 = new JLabel("NAMEOFINFORMER");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_1.setBounds(379, 94, 199, 45);
		frame.getContentPane().add(lblNewLabel_1);
		
		lblNewLabel_2 = new JLabel("DESCRIPTIONOFOFFENCE");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_2.setBounds(797, 104, 229, 23);
		frame.getContentPane().add(lblNewLabel_2);
		
		lblNewLabel_3 = new JLabel("NAMEOFCRIMINAL");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_3.setBounds(611, 103, 164, 26);
		frame.getContentPane().add(lblNewLabel_3);
		
		JLabel lblNewLabel = new JLabel("OFFICER NAME");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel.setBounds(29, 99, 132, 32);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_4 = new JLabel("OfficerPhoneNo");
		lblNewLabel_4.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_4.setBounds(175, 104, 124, 23);
		frame.getContentPane().add(lblNewLabel_4);
		}
		catch(Exception E)
        { 
        	System.out.println(E);
        }  
		
		
	}
}

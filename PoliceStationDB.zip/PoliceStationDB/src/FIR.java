import java.awt.Color;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableModel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.PreparedStatement;
import java.awt.event.ActionEvent;

 class ADDFIR {

	private JFrame frame;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;
	Connection con;
	Statement stmt;
	ResultSet rs;
	private JTextField textField_3;

	/**
	 * Create the application.
	 */
	public ADDFIR() {
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		} 
		catch (Exception e) 
		{
			System.err.println("Unable to find and load driver");
			System.exit(1);
		}
		connectToDB();
		initialize();
		this.frame.setVisible(true);
	}
    void connectToDB() 
    {
		try 
		{
		 con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","saikumar","sql");
		  stmt = con.createStatement();

		} 
		catch (SQLException connectException) 
		{
		  System.out.println(connectException.getMessage());
		  System.out.println(connectException.getSQLState());
		  System.out.println(connectException.getErrorCode());
		  System.exit(1);
		}
    }
	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 926, 506);
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("FIR ID");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblNewLabel.setBounds(113, 36, 165, 32);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("NAME OF THE INFORMER");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblNewLabel_1.setBounds(51, 111, 217, 32);
		frame.getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("NAME OF CRIMINAL");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblNewLabel_2.setBounds(91, 175, 177, 39);
		frame.getContentPane().add(lblNewLabel_2);
		
		textField = new JTextField();
		textField.setBounds(299, 41, 189, 28);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setBounds(299, 116, 189, 28);
		frame.getContentPane().add(textField_1);
		textField_1.setColumns(10);
		
		textField_2 = new JTextField();
		textField_2.setBounds(298, 181, 190, 31);
		frame.getContentPane().add(textField_2);
		textField_2.setColumns(10);
		
		textField_3 = new JTextField();
		textField_3.setBounds(299, 246, 188, 32);
		frame.getContentPane().add(textField_3);
		textField_3.setColumns(10);
		
		JButton btnNewButton = new JButton("ADD DETAILS");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (e.getSource() == btnNewButton) {
					  String nameofinformer;
			           String NAMEOFCRIMINAL;
			           String DESCRIPTIONOFOFFENCE;
			            int id;
			            id = Integer.parseInt(textField.getText());
			            nameofinformer=textField_1.getText();
			            NAMEOFCRIMINAL=textField_2.getText();
			            DESCRIPTIONOFOFFENCE=textField_3.getText();
			            try {
			            //System.out.println(userText);
			            	 PreparedStatement pstmt = con.prepareStatement("insert into FIR values (?,?,?,?)");
			            	        pstmt.setInt(1, id);
			            	        pstmt.setString(2,  nameofinformer);
			            	        pstmt.setString(3,  NAMEOFCRIMINAL);
			            	        pstmt.setString(4,  DESCRIPTIONOFOFFENCE);
			            	        int i=pstmt.executeUpdate();  
						    //txtmsg.append("\nInserted " + i + " rows successfully");
							JOptionPane.showMessageDialog(null, "\nInserted " + i + " rows successfully");
				   }
			            catch(Exception E)
			            { System.out.println(E);}  
			}
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 16));
		btnNewButton.setBounds(227, 344, 189, 39);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("clear");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				  if (e.getSource() == btnNewButton_1) {
					  textField.setText("");
					  textField_1.setText("");
					  textField_2.setText("");
					  textField_3.setText("");
			        }
			}
		});
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 16));
		btnNewButton_1.setBounds(489, 344, 120, 39);
		frame.getContentPane().add(btnNewButton_1);
		
		JLabel lblNewLabel_3 = new JLabel("DESCRIPTION OF OFFENCE");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 15));
		lblNewLabel_3.setBounds(51, 243, 235, 32);
		frame.getContentPane().add(lblNewLabel_3);
		
		
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}
 
 
 
 class DELETEFIR {

 	private JFrame frame;
 	private JTextField textField;
 	private JTextField textField_1;
 	private JTextField textField_2;
 	Connection con;
 	Statement stmt;
 	ResultSet rs;
 	private JTextField textField_3;
 	/**
 	 * Create the application.
 	 */
 	public DELETEFIR() {
 		try 
 		{
 			Class.forName("oracle.jdbc.driver.OracleDriver");
 		} 
 		catch (Exception e) 
 		{
 			System.err.println("Unable to find and load driver");
 			System.exit(1);
 		}
 		connectToDB();
 		initialize();
 		this.frame.setVisible(true);
 	}
 	 void connectToDB() 
 	    {
 			try 
 			{
 			 con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","saikumar","sql");
 			  stmt = con.createStatement();

 			} 
 			catch (SQLException connectException) 
 			{
 			  System.out.println(connectException.getMessage());
 			  System.out.println(connectException.getSQLState());
 			  System.out.println(connectException.getErrorCode());
 			  System.exit(1);
 			}
 	    }
 	/**
 	 * Initialize the contents of the frame.
 	 */
 	private void initialize() {
 		frame = new JFrame();
 		frame.setBounds(100, 100, 854, 505);
 		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
 		frame.getContentPane().setLayout(null);
 		
 		JLabel lblNewLabel = new JLabel("FIRID");
 		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 16));
 		lblNewLabel.setBounds(173, 88, 68, 38);
 		frame.getContentPane().add(lblNewLabel);
 		
 		JLabel lblNewLabel_1 = new JLabel("NAME OF INFORMER");
 		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 16));
 		lblNewLabel_1.setBounds(81, 191, 181, 29);
 		frame.getContentPane().add(lblNewLabel_1);
 		
 		JLabel lblNewLabel_2 = new JLabel("NAME OF CRIMINAL");
 		lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 17));
 		lblNewLabel_2.setBounds(81, 251, 166, 29);
 		frame.getContentPane().add(lblNewLabel_2);
 		
 		textField = new JTextField();
 		textField.setBounds(268, 95, 96, 29);
 		frame.getContentPane().add(textField);
 		textField.setColumns(10);
 		
 		textField_1 = new JTextField();
 		textField_1.setBounds(281, 195, 139, 26);
 		frame.getContentPane().add(textField_1);
 		textField_1.setColumns(10);
 		
 		textField_2 = new JTextField();
 		textField_2.setBounds(281, 255, 139, 27);
 		frame.getContentPane().add(textField_2);
 		textField_2.setColumns(10);
 		
 		JButton btnNewButton = new JButton("DELETE");
 		btnNewButton.addActionListener(new ActionListener() {
 			public void actionPerformed(ActionEvent e) {
 				if (e.getSource() == btnNewButton) {
 					  String nameofinformer;
 			           String NAMEOFCRIMINAL;
 			           String DESCRIPTIONOFOFFENCE;
 			            int id;
 			            id = Integer.parseInt(textField.getText());
 			            nameofinformer=textField_1.getText();
 			            NAMEOFCRIMINAL=textField_2.getText();
 			            DESCRIPTIONOFOFFENCE=textField_3.getText();
 			            try {
 			            //System.out.println(userText);
 			            	 PreparedStatement pstmt = con.prepareStatement("delete from FIR where FIRID=(?) and NAMEOFINFORMER=(?)");
 			            	        pstmt.setInt(1, id);
 			            	        pstmt.setString(2,  nameofinformer);
 			            	     //   pstmt.setString(3,  NAMEOFCRIMINAL);
 			            	      //  pstmt.setString(4,  DESCRIPTIONOFOFFENCE);
 			            	        int i=pstmt.executeUpdate();  
 						    //txtmsg.append("\nInserted " + i + " rows successfully");
 							JOptionPane.showMessageDialog(null, "\nUpdated " + i + " rows successfully");
 				   }
 			            catch(Exception E)
 			            { System.out.println(E);}  
 			}
 			}
 		});
 		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 16));
 		btnNewButton.setBounds(143, 394, 104, 38);
 		frame.getContentPane().add(btnNewButton);
 		
 		JButton btnNewButton_1 = new JButton("VIEW FIR DETAILS");
 		btnNewButton_1.addActionListener(new ActionListener() {
 			public void actionPerformed(ActionEvent e) {
 				if (e.getSource() == btnNewButton_1) {	
 				  VIEWFIR vf=new VIEWFIR();
 				}
 			}
 		});
 		btnNewButton_1.setFont(new Font("Tahoma", Font.PLAIN, 15));
 		btnNewButton_1.setBounds(370, 394, 189, 38);
 		frame.getContentPane().add(btnNewButton_1);
 		
 		JTextArea txtrMandotory = new JTextArea();
 		txtrMandotory.setBackground(new Color(255, 255, 255));
 		txtrMandotory.setFont(new Font("Monospaced", Font.PLAIN, 17));
 		txtrMandotory.setText("Id is Mandotory!");
 		txtrMandotory.setBounds(160, 136, 205, 29);
 		frame.getContentPane().add(txtrMandotory);
 		
 		JLabel lblNewLabel_3 = new JLabel("DELETE FIR");
 		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 18));
 		lblNewLabel_3.setBounds(228, 35, 179, 29);
 		frame.getContentPane().add(lblNewLabel_3);
 		
 		JLabel lblNewLabel_4 = new JLabel("DESCRIPTION OF OFFENCE");
 		lblNewLabel_4.setFont(new Font("Tahoma", Font.BOLD, 16));
 		lblNewLabel_4.setBounds(22, 319, 249, 29);
 		frame.getContentPane().add(lblNewLabel_4);
 		
 		textField_3 = new JTextField();
 		textField_3.setBounds(283, 317, 249, 38);
 		frame.getContentPane().add(textField_3);
 		textField_3.setColumns(10);
 	}
 }
 
 class EDITFIR {

		private JFrame frame;
		private JTextField textField;
		private JTextField textField_1;
		private JTextField textField_2;
		Connection con;
		Statement stmt;
		ResultSet rs;
		private JTextField textField_3;
		/**
		 * Create the application.
		 */
		public EDITFIR() {
			try 
			{
				Class.forName("oracle.jdbc.driver.OracleDriver");
			} 
			catch (Exception e) 
			{
				System.err.println("Unable to find and load driver");
				System.exit(1);
			}
			connectToDB();
			initialize();
			this.frame.setVisible(true);
		}
		 void connectToDB() 
		    {
				try 
				{
				 con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","saikumar","sql");
				  stmt = con.createStatement();

				} 
				catch (SQLException connectException) 
				{
				  System.out.println(connectException.getMessage());
				  System.out.println(connectException.getSQLState());
				  System.out.println(connectException.getErrorCode());
				  System.exit(1);
				}
		    }
		/**
		 * Initialize the contents of the frame.
		 */
		private void initialize() {
			frame = new JFrame();
			frame.setBounds(100, 100, 854, 505);
			frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
			frame.getContentPane().setLayout(null);
			
			JLabel lblNewLabel = new JLabel("FIRID");
			lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 16));
			lblNewLabel.setBounds(173, 88, 68, 38);
			frame.getContentPane().add(lblNewLabel);
			
			JLabel lblNewLabel_1 = new JLabel("NAME OF INFORMER");
			lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 16));
			lblNewLabel_1.setBounds(81, 191, 181, 29);
			frame.getContentPane().add(lblNewLabel_1);
			
			JLabel lblNewLabel_2 = new JLabel("NAME OF CRIMINAL");
			lblNewLabel_2.setFont(new Font("Tahoma", Font.PLAIN, 17));
			lblNewLabel_2.setBounds(81, 251, 166, 29);
			frame.getContentPane().add(lblNewLabel_2);
			
			textField = new JTextField();
			textField.setBounds(268, 95, 96, 29);
			frame.getContentPane().add(textField);
			textField.setColumns(10);
			
			textField_1 = new JTextField();
			textField_1.setBounds(281, 195, 139, 26);
			frame.getContentPane().add(textField_1);
			textField_1.setColumns(10);
			
			textField_2 = new JTextField();
			textField_2.setBounds(281, 255, 139, 27);
			frame.getContentPane().add(textField_2);
			textField_2.setColumns(10);
			
			JButton btnNewButton = new JButton("EDIT");
			btnNewButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if (e.getSource() == btnNewButton) {
						  String nameofinformer;
				           String NAMEOFCRIMINAL;
				           String DESCRIPTIONOFOFFENCE;
				            int id;
				            id = Integer.parseInt(textField.getText());
				            nameofinformer=textField_1.getText();
				            NAMEOFCRIMINAL=textField_2.getText();
				            DESCRIPTIONOFOFFENCE=textField_3.getText();
				            try {
				            //System.out.println(userText);
				            	 PreparedStatement pstmt = con.prepareStatement("update FIR set NAMEOFINFORMER=(?),NAMEOFCRIMINAL=(?),DESCRIPTIONOFOFFENCE=(?) where FIRID=(?)");
				            	        pstmt.setInt(4, id);
				            	        pstmt.setString(1,  nameofinformer);
				            	        pstmt.setString(2,  NAMEOFCRIMINAL);
				            	        pstmt.setString(3,  DESCRIPTIONOFOFFENCE);
				            	        int i=pstmt.executeUpdate();  
							    //txtmsg.append("\nInserted " + i + " rows successfully");
								JOptionPane.showMessageDialog(null, "\nUpdated " + i + " rows successfully");
					   }
				            catch(Exception E)
				            { System.out.println(E);}  
				}
				}
			});
			btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 16));
			btnNewButton.setBounds(143, 394, 104, 38);
			frame.getContentPane().add(btnNewButton);
			
			JButton btnNewButton_1 = new JButton("VIEW FIR DETAILS");
			btnNewButton_1.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if (e.getSource() == btnNewButton_1) {	
					  VIEWFIR vf=new VIEWFIR();
					}
				}
			});
			btnNewButton_1.setFont(new Font("Tahoma", Font.PLAIN, 15));
			btnNewButton_1.setBounds(370, 394, 189, 38);
			frame.getContentPane().add(btnNewButton_1);
			
			JTextArea txtrMandotory = new JTextArea();
			txtrMandotory.setBackground(new Color(255, 255, 255));
			txtrMandotory.setFont(new Font("Monospaced", Font.PLAIN, 17));
			txtrMandotory.setText("Id is Mandotory!");
			txtrMandotory.setBounds(160, 136, 205, 29);
			frame.getContentPane().add(txtrMandotory);
			
			JLabel lblNewLabel_3 = new JLabel("EDIT FIR");
			lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 18));
			lblNewLabel_3.setBounds(228, 35, 179, 29);
			frame.getContentPane().add(lblNewLabel_3);
			
			JLabel lblNewLabel_4 = new JLabel("DESCRIPTION OF OFFENCE");
			lblNewLabel_4.setFont(new Font("Tahoma", Font.BOLD, 16));
			lblNewLabel_4.setBounds(22, 319, 249, 29);
			frame.getContentPane().add(lblNewLabel_4);
			
			textField_3 = new JTextField();
			textField_3.setBounds(283, 317, 249, 38);
			frame.getContentPane().add(textField_3);
			textField_3.setColumns(10);
		}
	}

 class VIEWFIR {

		private JFrame frame;
		private JTable table;
	    String[][] tbl=new String[100][100];
	    Connection con;
		Statement stmt;
		ResultSet rs;
		private JLabel lblNewLabel;
		private JLabel lblNewLabel_1;
		private JLabel lblNewLabel_2;
		private JLabel lblNewLabel_3;
		/**
		 * Create the application.
		 */
		 VIEWFIR() {
			try 
			{
				Class.forName("oracle.jdbc.driver.OracleDriver");
			} 
			catch (Exception e) 
			{
				System.err.println("Unable to find and load driver");
				System.exit(1);
			}
			connectToDB();
			initialize();
			this.frame.setVisible(true);
		}
		 void connectToDB() 
		    {
				try 
				{
				 con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","saikumar","sql");
				  stmt = con.createStatement();

				} 
				catch (SQLException connectException) 
				{
				  System.out.println(connectException.getMessage());
				  System.out.println(connectException.getSQLState());
				  System.out.println(connectException.getErrorCode());
				  System.exit(1);
				}
		    }
		/**
		 * Initialize the contents of the frame.
		 */
		private void initialize() {
			frame = new JFrame();
			frame.setBounds(100, 100, 797, 503);
			frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
			frame.getContentPane().setLayout(null);
			
			JTextPane txtpnOfficerDetails = new JTextPane();
			txtpnOfficerDetails.setFont(new Font("Tahoma", Font.BOLD, 21));
			txtpnOfficerDetails.setText("FIR DETAILS");
			txtpnOfficerDetails.setBounds(227, 25, 239, 32);
			frame.getContentPane().add(txtpnOfficerDetails);
			try {
				ResultSet rs=stmt.executeQuery("select * from FIR");
				
				int i=0;
				while(rs.next()) {
					
					//System.out.println(rs.getString(1)+" "+rs.getString(2)+" "+rs.getString(3));
					
					tbl[i][0]=rs.getString(1);
					tbl[i][1]=rs.getString(2);
					tbl[i][2]=rs.getString(3); 
					tbl[i][3]=rs.getString(4); 
					i=i+1;
					
				}
				/*for(int j=0;i<5;i++) {
				System.out.println(tbl[i][0]+" "+tbl[i][1]+" "+tbl[i][2]+" ");
				}*/
				
			
			table = new JTable();
			table.setRowSelectionAllowed(false);
			table.setSurrendersFocusOnKeystroke(true);
			table.setModel(new DefaultTableModel(
				tbl,
				new String[] {
					"OFFICER ID", "NAME", "PHONENO", "New column"
				}
			));
			table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
			table.setBounds(29, 137, 723, 121);
			frame.getContentPane().add(table);
			
			lblNewLabel = new JLabel("FIRID");
			lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 17));
			lblNewLabel.setBounds(48, 101, 235, 26);
			frame.getContentPane().add(lblNewLabel);
			
			lblNewLabel_1 = new JLabel("NAMEOFINFORMER");
			lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 17));
			lblNewLabel_1.setBounds(182, 92, 199, 45);
			frame.getContentPane().add(lblNewLabel_1);
			
			lblNewLabel_2 = new JLabel("DESCRIPTIONOFOFFENCE");
			lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 17));
			lblNewLabel_2.setBounds(544, 104, 229, 23);
			frame.getContentPane().add(lblNewLabel_2);
			
			lblNewLabel_3 = new JLabel("NAMEOFCRIMINAL");
			lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 17));
			lblNewLabel_3.setBounds(370, 102, 164, 26);
			frame.getContentPane().add(lblNewLabel_3);
			}
			catch(Exception E)
	        { 
	        	System.out.println(E);
	        }  
			
			
		}
	}


